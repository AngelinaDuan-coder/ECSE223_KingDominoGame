package ca.mcgill.ecse223.kingdomino.model;

public enum TerrainType {
	WheatField, 
	Forest, 
	Lake, 
	Grass, 
	Swamp, 
	Mountain
}
