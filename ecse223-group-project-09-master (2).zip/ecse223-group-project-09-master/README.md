# We have 60 minutes left! :warning:

### Schedule:
| Date | What I have done. | Left  |
| ------------- | ------------- | ------------- |
| **04.13** | 1.Greated the GUI JFrame. --Kua<br/>| 1.Pass Iteration-3 JUnit Test<br/> 2.Comprehend the StateMachine<br/>3.Write report on Wiki column<br/> 4.Finish the corresponding GUI parts(Assigned by your features) <br/>5. <br/>6. <br/>  |
| **04.14**  | 1. Finished SelecingDomino and SelecingFirstDomino feature tests! @Kua Test<br/> 2.Finish testing GamePlay of creatingFirst Draft @Kua @Angelina| |
| **04.15**  | | |
| **04.16**  |1. Add Jlabel to display property score and bonus score @Kua | |
| **04.17**  | | Please fill out the work distribution sheet as soos as possible. Fill out what you have done |
| **Problems**  | | |
| **Others**  | | |
